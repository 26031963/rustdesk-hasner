pub const VERSION: &str = "1.4.0";
#[allow(dead_code)]
pub const BUILD_DATE: &str = "2025-07-02 23:16";
